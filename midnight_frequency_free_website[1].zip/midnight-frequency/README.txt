MIDNIGHT FREQUENCY — FREE WEBSITE STARTER

Files:
- index.html: the complete responsive website. No paid theme, plugins, or external libraries required.

Preview:
Open index.html in a browser.

Publish for free with GitHub Pages:
1. Create/sign in to a free GitHub account.
2. Create a new public repository named midnight-frequency.
3. Upload index.html to the repository's main/root folder.
4. Open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Choose the main branch and /(root), then Save.
7. GitHub will provide your public website address after publishing.

Before launch:
- Replace the “coming to the archive” placeholders with links to your published Medium stories.
- Add your YouTube channel link when ready.
- If you want a custom domain (for example midnightfrequency.com), domain registration usually costs money; the GitHub Pages address is free.

This is a static site, so it does not require a paid hosting plan or database. The archive cards are starter placeholders, not live story links.
